import { Component, OnInit } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators'; // Import the 'map' operator

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  langChange$!: Observable<string>;

  constructor(private router: Router, public translate: TranslateService) {
    translate.addLangs(['en', 'vn']);
    translate.setDefaultLang('en');

    const browserLang = translate.getBrowserLang();
    const selectedLang =
      browserLang && browserLang.match(/en|vn/) ? browserLang : 'vn';
    this.changeLanguage(selectedLang);
  }

  ngOnInit() {
    this.langChange$ = this.translate.onLangChange.pipe(
      map((event: LangChangeEvent) => event.lang)
    );
  }

  changeLanguage(selectedLang: string): void {
    this.translate.use(selectedLang);

    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([this.router.url]);
  }
}
