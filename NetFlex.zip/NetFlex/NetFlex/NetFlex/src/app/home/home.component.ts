import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  trendingMovies: any;
  theatreMovies: any;
  popularMovies: any;
  topRatedMovies: any;

  currentLanguage: string = '';

  constructor(
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.getTrendingMovies();
    this.getTheatreMovies();
    this.getPopularMovies();
    this.getCurrentLanguage();
  }

  updateTopRatedMovies() {
    if (this.trendingMovies && this.theatreMovies && this.popularMovies) {
      // Combine all movies into a single array
      const allMovies = [
        ...this.trendingMovies,
        ...this.theatreMovies,
        ...this.popularMovies,
      ];

      // Sort the movies by rating in descending order
      allMovies.sort((a, b) => b.rating - a.rating);

      // Take the top 9 movies
      this.topRatedMovies = allMovies.slice(0, 9);
    }
  }

  showAllMovies: { [key: string]: boolean } = {};

  // Function to toggle the flag when "View All" is clicked
  toggleShowAllMovies(type: string) {
    this.showAllMovies[type] = !this.showAllMovies[type];
  }

  getCurrentLanguage() {
    this.currentLanguage = this.translate.currentLang;
    console.log('Current Language:', this.currentLanguage);
    // Bạn có thể thực hiện các xử lý khác dựa trên giá trị của this.currentLanguage
  }

  getTrendingMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/trending-movies.json')
      .subscribe((movies) => {
        this.trendingMovies = this.addOriginalArray(movies, 'trending');
        this.updateTopRatedMovies();
      });
  }

  getTheatreMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/theatre-movies.json')
      .subscribe((movies) => {
        this.theatreMovies = this.addOriginalArray(movies, 'theatre');
        this.updateTopRatedMovies();
      });
  }

  getPopularMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/popular-movies.json')
      .subscribe((movies) => {
        this.popularMovies = this.addOriginalArray(movies, 'popular');
        this.updateTopRatedMovies();
      });
  }

  addOriginalArray(movies: any[], type: string) {
    return movies.map((movie) => ({ ...movie, originalArray: type }));
  }

  goToMovie(type: string, id: string) {
    this.router.navigate(['movie', type, id]).then(() => {
      this.scrollToTop();
    });
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
