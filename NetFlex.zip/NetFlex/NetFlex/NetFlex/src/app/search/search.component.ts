//search.component.ts

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
})
export class SearchComponent implements OnInit {
  trendingMovies: any;
  theatreMovies: any;
  popularMovies: any;
  currentLanguage: string = '';
  searchTerm: string = '';
  langChangeSubscription: Subscription = new Subscription();

  constructor(
    private http: HttpClient,
    private router: Router,
    private translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.currentLanguage = this.translate.currentLang;
    this.langChangeSubscription = this.translate.onLangChange
      .pipe(map((event: LangChangeEvent) => event.lang))
      .subscribe((lang) => {
        this.currentLanguage = lang;
        this.getTrendingMovies();
        this.getTheatreMovies();
        this.getPopularMovies();
      });

    this.getCurrentLanguage();
  }

  ngOnDestroy(): void {
    if (this.langChangeSubscription) {
      this.langChangeSubscription.unsubscribe();
    }
  }

  getCurrentLanguage() {
    this.currentLanguage = this.translate.currentLang;
    console.log('Current Language---:', this.currentLanguage);
  }

  getTrendingMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/trending-movies.json')
      .subscribe((movies) => {
        this.trendingMovies = this.addOriginalArray(movies, 'trending');
      });
  }

  getTheatreMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/theatre-movies.json')
      .subscribe((movies) => {
        this.theatreMovies = this.addOriginalArray(movies, 'theatre');
      });
  }

  getPopularMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/popular-movies.json')
      .subscribe((movies) => {
        this.popularMovies = this.addOriginalArray(movies, 'popular');
      });
  }

  addOriginalArray(movies: any[], type: string) {
    return movies.map((movie) => ({ ...movie, originalArray: type }));
  }

  onSearchInput() {
    this.searchMovies();
  }

  searchMovies() {
    const filteredMovies = this.filterMovies(
      this.searchTerm,
      this.currentLanguage
    );
    console.log(filteredMovies);

    this.router.navigate(['/showlist'], {
      queryParams: { filteredMovies: JSON.stringify(filteredMovies) },
    });
  }

  filterMovies(searchTerm: string, language: string): any[] {
    if (!searchTerm) {
      return [];
    }

    const allMovies = [
      ...(this.trendingMovies || []),
      ...(this.theatreMovies || []),
      ...(this.popularMovies || []),
    ];
    console.log(allMovies);

    return allMovies.filter((movie) => {
      const nameToSearch = language === 'en' ? movie.name_en : movie.name_vn;

      return nameToSearch.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }

  onEnterPressed() {
    this.searchMovies();
  }

  navigateToShowList(filteredMovies: any[]) {
    this.router.navigate(['/showlist'], {
      queryParams: { filteredMovies: JSON.stringify(filteredMovies) },
    });
  }
}
