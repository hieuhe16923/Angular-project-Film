// footer.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']  // You can create a CSS file for styling
})
export class FooterComponent {
  // You can add any necessary properties or methods here
}
