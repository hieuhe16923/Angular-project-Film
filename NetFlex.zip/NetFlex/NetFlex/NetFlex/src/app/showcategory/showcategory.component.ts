// showcategory.component.ts
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-showcategory',
  templateUrl: './showcategory.component.html',
  styleUrls: ['./showcategory.component.css'],
})
export class ShowCategoryComponent implements OnInit {
  currentLanguage: string = '';
  categorymovie: any[] = [];
  selectedMovie: any; // Thêm thuộc tính để lưu trữ chi tiết phim được chọn
  topRatedMovies: any;
  trendingMovies: any;
  theatreMovies: any;
  popularMovies: any;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      if (params['categoryMovies']) {
        this.categorymovie = JSON.parse(params['categoryMovies']);
        console.log(this.categorymovie);
      }
    });
    this.getCurrentLanguage();
    this.getTrendingMovies();
    this.getTheatreMovies();
    this.getPopularMovies();
  }
  updateTopRatedMovies() {
    if (this.trendingMovies && this.theatreMovies && this.popularMovies) {
      // Combine all movies into a single array
      const allMovies = [
        ...this.trendingMovies,
        ...this.theatreMovies,
        ...this.popularMovies,
      ];

      // Sort the movies by rating in descending order
      allMovies.sort((a, b) => b.rating - a.rating);

      // Take the top 9 movies
      this.topRatedMovies = allMovies.slice(0, 9);
    }
  }
  getCurrentLanguage() {
    this.currentLanguage = this.translate.currentLang;
  }
  addOriginalArray(movies: any[], type: string) {
    return movies.map((movie) => ({ ...movie, originalArray: type }));
  }

  goToMovie(type: string, id: string) {
    this.router.navigate(['movie', type, id]).then(() => {});
  }
  showMovieDetails(movie: any): void {
    this.selectedMovie = movie;
  }
  getTrendingMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/trending-movies.json')
      .subscribe((movies) => {
        this.trendingMovies = this.addOriginalArray(movies, 'trending');
        this.updateTopRatedMovies();
      });
  }

  getTheatreMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/theatre-movies.json')
      .subscribe((movies) => {
        this.theatreMovies = this.addOriginalArray(movies, 'theatre');
        this.updateTopRatedMovies();
      });
  }

  getPopularMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/popular-movies.json')
      .subscribe((movies) => {
        this.popularMovies = this.addOriginalArray(movies, 'popular');
        this.updateTopRatedMovies();
      });
  }
}
