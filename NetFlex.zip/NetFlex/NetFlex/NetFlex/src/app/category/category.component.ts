import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { log } from 'node:console';

interface Movie {
  id: number;
  name_en: string;
  name_vn: string;
  cover: string;
  rating: number;
  category: string;
  reviews: any[];
  originalArray?: string; // Adding originalArray to the Movie interface
}

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css'],
})
export class CategoryComponent implements OnInit, OnDestroy {
  trendingMovies: Movie[] = [];
  theatreMovies: Movie[] = [];
  popularMovies: Movie[] = [];
  currentLanguage = '';
  searchTerm = '';
  langChangeSubscription: Subscription = new Subscription();

  constructor(
    private http: HttpClient,
    private router: Router,
    private translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.getCurrentLanguage();
    this.subscribeToLanguageChange();
    this.loadData();
  }

  ngOnDestroy(): void {
    this.langChangeSubscription.unsubscribe();
  }

  getCurrentLanguage(): void {
    this.currentLanguage = this.translate.currentLang;
    console.log('Current Language:', this.currentLanguage);
  }

  subscribeToLanguageChange(): void {
    this.langChangeSubscription = this.translate.onLangChange
      .pipe(map((event: LangChangeEvent) => event.lang))
      .subscribe((lang) => {
        this.currentLanguage = lang;
        this.loadData();
      });
  }

  loadData(): void {
    this.getTrendingMovies();
    this.getTheatreMovies();
    this.getPopularMovies();
  }

  getTrendingMovies(): void {
    this.http
      .get<Movie[]>('/assets/data/trending-movies.json') // Adjusted the URL
      .subscribe((movies) => {
        this.trendingMovies = this.addOriginalArray(movies, 'trending');
      });
  }

  getTheatreMovies(): void {
    this.http
      .get<Movie[]>('/assets/data/theatre-movies.json') // Adjusted the URL
      .subscribe((movies) => {
        this.theatreMovies = this.addOriginalArray(movies, 'theatre');
      });
  }

  getPopularMovies(): void {
    this.http
      .get<Movie[]>('/assets/data/popular-movies.json') // Adjusted the URL
      .subscribe((movies) => {
        this.popularMovies = this.addOriginalArray(movies, 'popular');
      });
  }

  addOriginalArray(movies: Movie[], type: string): Movie[] {
    return movies.map((movie) => ({ ...movie, originalArray: type }));
  }

  selectCategory(category: string): void {
    this.searchTerm = category;
    const categoryMovies = this.filterMovies(this.searchTerm);
    console.log('Category Movies:', categoryMovies);

    this.router.navigate(['/showcategory'], {
      queryParams: { categoryMovies: JSON.stringify(categoryMovies) },
    });
  }

  filterMovies(searchTerm: string): Movie[] {
    if (!searchTerm) {
      return [];
    }

    const allMovies = [
      ...this.trendingMovies,
      ...this.theatreMovies,
      ...this.popularMovies,
    ];
    console.log(allMovies);

    return allMovies.filter((movie) =>
      movie.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }
}
