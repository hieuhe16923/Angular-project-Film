import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css'],
})
export class MovieComponent implements OnInit {
  trendingMovies: any;
  theatreMovies: any;
  popularMovies: any;
  topRatedMovies: any;
  suggestMovies: any;
 
  type = '';
  id = '';
  url = '';
  movies: any;
  movie: any;

  // Thêm các biến để lưu giá trị nhập liệu từ form
  userName: string = '';
  userRating: number = 0;
  userReview: string = '';

  currentLanguage: string = '';

  isUserNameInvalid: boolean = false;
  isUserRatingInvalid: boolean = false;
  isUserReviewEmpty: boolean = false;
  urlSafe: SafeResourceUrl = '';
  epUrl: SafeResourceUrl = '';
  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private routerFilm: Router,
    private translate: TranslateService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    
    this.route.params.subscribe((params) => {
      this.type = params['type'];
      this.id = params['id'];

      if (this.type === 'trending') {
        this.url = 'http://localhost:4200/assets/data/trending-movies.json';
      }
      if (this.type === 'theatre') {
        this.url = 'http://localhost:4200/assets/data/theatre-movies.json';
      }
      if (this.type === 'popular') {
        this.url = 'http://localhost:4200/assets/data/popular-movies.json';
      }
      if (this.type === 'suggest') {
        this.url = 'http://localhost:4200/assets/data/suggest-movies.json';
      }
      this.getMovie();
    });
    this.getTrendingMovies();
    this.getTheatreMovies();
    this.getPopularMovies();
    this.getSuggestMovies();
    this.getCurrentLanguage();
    
  }

  getMovie() {
    this.http.get(this.url).subscribe((movies) => {
      this.movies = movies;
      let index = this.movies.findIndex(
        (movie: { id: string }) => movie.id == this.id
      );
      if (index > -1) {
        this.movie = this.movies[index];
        this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.movies[index].trailer);
        this.epUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.movies[index].ep);
      }
    });
    
  }

  onRatingChanged(event: number) {
    this.userRating = event;
    this.isUserRatingInvalid = false; // Reset validation status
  }

  // Hàm xử lý khi người dùng nhấn submit
  onSubmit() {
    // Kiểm tra nếu userName hoặc userRating bị bỏ trống
    if (!this.userName.trim() || this.userRating === 0) {
      if (!this.userName.trim()) {
        this.isUserNameInvalid = true;
      }
      if (this.userRating === 0) {
        this.isUserRatingInvalid = true;
      }
      return; // Không thực hiện submit nếu có lỗi
    }

    // Kiểm tra nếu userReview bị bỏ trống
    if (!this.userReview.trim()) {
      this.isUserReviewEmpty = true;
      this.userReview = 'EMPTY';
    }
    // Tạo một đối tượng mới để lưu đánh giá từ người dùng
    const newReview = {
      author: this.userName,
      rating: this.userRating,
      review: this.userReview,
      published_on: new Date(), // Ngày hiện tại
    };

    // Thêm đánh giá mới vào danh sách đánh giá của phim
    this.movie.reviews.push(newReview);

    // Đặt lại các giá trị nhập liệu
    this.userName = '';
    this.userRating = 0;
    this.userReview = '';

    this.isUserNameInvalid = false;
    this.isUserRatingInvalid = false;
    this.isUserReviewEmpty = false;
  }
  getCurrentLanguage() {
    this.currentLanguage = this.translate.currentLang;
    console.log('Current Language:', this.currentLanguage);
    // Bạn có thể thực hiện các xử lý khác dựa trên giá trị của this.currentLanguage
  }
  updateTopRatedMovies() {
    if (this.trendingMovies && this.theatreMovies && this.popularMovies) {
      // Combine all movies into a single array
      const allMovies = [
        ...this.trendingMovies,
        ...this.theatreMovies,
        ...this.popularMovies,
      ];

      // Sort the movies by rating in descending order
      allMovies.sort((a, b) => b.rating - a.rating);

      // Take the top 9 movies
      this.topRatedMovies = allMovies.slice(0, 9);
    }
  }
  getTrendingMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/trending-movies.json')
      .subscribe((movies) => {
        this.trendingMovies = this.addOriginalArray(movies, 'trending');
        this.updateTopRatedMovies();
      });
  }

  getTheatreMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/theatre-movies.json')
      .subscribe((movies) => {
        this.theatreMovies = this.addOriginalArray(movies, 'theatre');
        this.updateTopRatedMovies();
      });
  }

  getPopularMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/popular-movies.json')
      .subscribe((movies) => {
        this.popularMovies = this.addOriginalArray(movies, 'popular');
        this.updateTopRatedMovies();
      });
  }

  addOriginalArray(movies: any[], type: string) {
    return movies.map((movie) => ({ ...movie, originalArray: type }));
  }

  getSuggestMovies() {
    this.http
      .get<any[]>('http://localhost:4200/assets/data/suggest-movies.json')
      .subscribe((movies) => {
        // Shuffle the array randomly
        const shuffledMovies = this.shuffleArray(movies);

        // Take the first 4 elements
        this.suggestMovies = shuffledMovies.slice(0, 4);
      });
  }

  shuffleArray(array: any[]) {
    // Fisher-Yates shuffle algorithm
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  goToMovie(type: string, id: string) {
    this.routerFilm.navigate(['movie', type, id]).then(() => {
      this.scrollToTop();
    });
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
