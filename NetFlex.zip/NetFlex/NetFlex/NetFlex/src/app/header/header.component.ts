import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators'; // Import the 'map' operator
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent implements OnInit {
  langChange$!: Observable<string>;

  constructor(private router: Router, private auth: AuthService,public translate: TranslateService) {translate.addLangs(['en', 'vn']);
  translate.setDefaultLang('en');

  const browserLang = translate.getBrowserLang();
  const selectedLang =
    browserLang && browserLang.match(/en|vn/) ? browserLang : 'vn';
  this.changeLanguage(selectedLang);}
  ngOnInit(): void {this.langChange$ = this.translate.onLangChange.pipe(
    map((event: LangChangeEvent) => event.lang)
  );}
  goToHome() {
    this.router.navigate(['home']);
  }
  logout() {
    this.auth.logout();
  }
  changeLanguage(selectedLang: string): void {
    this.translate.use(selectedLang);

    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([this.router.url]);
  }
}
