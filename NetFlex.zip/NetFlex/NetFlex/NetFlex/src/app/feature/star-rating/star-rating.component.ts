// star-rating.component.ts
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-star-rating',
  templateUrl: './star-rating.component.html',
  styleUrls: ['./star-rating.component.css'],
})
export class StarRatingComponent implements OnInit {
  @Input() rating: any;
  @Input() isReadOnly: boolean = false;
  @Output() ratingChange: EventEmitter<number> = new EventEmitter<number>();

  constructor() {}

  ngOnInit(): void {}

  onRateChange(event: number) {
    if (!this.isReadOnly) {
      // Emit the updated rating using the 'ratingChange' event
      this.ratingChange.emit(event);
    }
  }
}
