import {
  VgApiService,
  VgControlsHiddenService,
  VgCoreModule,
  VgCuePointsDirective,
  VgEvents,
  VgFullscreenApiService,
  VgMediaDirective,
  VgMediaElement,
  VgPlayerComponent,
  VgStates,
  VgUtilsService
} from "./chunk-GZJMSPYW.js";
import "./chunk-FRIKEHAD.js";
import "./chunk-HUWSEA2J.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  VgApiService,
  VgControlsHiddenService,
  VgCoreModule,
  VgCuePointsDirective,
  VgEvents,
  VgFullscreenApiService,
  VgMediaDirective,
  VgMediaElement,
  VgPlayerComponent,
  VgStates,
  VgUtilsService
};
//# sourceMappingURL=@videogular_ngx-videogular_core.js.map
